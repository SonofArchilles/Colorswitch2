package com.jacobjacob.colorswitch2;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    SeekBar sbGreen;
    SeekBar sbRed;
    SeekBar modes1;
    SeekBar sbBlue;
    SeekBar Time;
    TextView text;
    //RelativeLayout layout1 = (RelativeLayout)findViewById(R.id.layout1);

    public int green;
    public int red;
    public int modes;
    public int blue;
    public int time;
    public int r1;
    public int g1;
    public int b1;
    private RelativeLayout layout;
    //
    public int colorRed = 0;
    public int colorGreen = colorRed + 85;
    public int colorBlue = colorGreen + 85;
    public int xvalue;
    public double cR = 0;
    public double cG = 0;
    public double cB = 0;
    public int Red1 = 255;
    public int Green1 = 0;
    public int Blue1 = 0;
    public double xvalue1;
    public double yvalue1;
    //
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layout = findViewById(R.id.layout1);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

        sbRed = findViewById(R.id.sbRed);
        sbGreen = findViewById(R.id.sbGreen);
        sbBlue = findViewById(R.id.sbBlue);

        sbRed.setProgress(0);
        sbGreen.setProgress(0);
        sbBlue.setProgress(0);

        modes1 = findViewById(R.id.modes1);
        Time = findViewById(R.id.Time);
        text = findViewById(R.id.Text);

        text.setText("Red:"+red + "Green:" + green + "Blue:" + blue + "Mode:" + modes + "Steps:" + time);

        r1 =colorRed - 255;
        g1 = colorGreen - 255;
        b1 = colorBlue - 255;
        text.setTextColor(Color.rgb(r1,b1,g1));

        sbRed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                red = i;

                if(modes == 0) {
                    layout.setBackgroundColor(Color.argb(255, red, green, blue));
                    text.setText("Red:" + red + "Green:" + green + "Blue:" + blue + "Mode:" + modes + "Steps:" + time);
                }
                if (modes == 1) {
                    colorRed = time + 1;
                    colorGreen = colorRed + 85;
                    colorBlue = colorRed + 170;

                    if (colorRed > 255) colorRed = 0;
                    if (colorGreen > 255) colorGreen = colorGreen - 255;
                    if (colorBlue > 255) colorBlue = colorBlue - 255;

                    colorRed = (int)colorRed + 2 * (red - 127);

                    colorGreen = (int)colorGreen + 2 * (green - 127);

                    colorBlue = (int)colorBlue + 2 * (blue - 127);
                }

                if (modes == 2) {
                    cR = 255 / 2 + 255 / 2 * Math.sin(0.025 * time);
                    cG = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + 2 * Math.PI / 3);
                    cB = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + 4 * Math.PI / 3);
                    colorRed = (int) cR;
                    colorGreen = (int) cG;
                    colorBlue = (int) cB;


                    colorRed = (int)colorRed + 2 * (red - 127);

                    colorGreen = (int)colorGreen + 2 * (green - 127);

                    colorBlue = (int)colorBlue + 2 * (blue - 127);

                }

                if (modes == 3) {
                    time = time + 1;
                    if (time > 255) time = 0;
                    cR = 255 / 2 + 255 / 2 * Math.sin(0.025 * time);
                    cG = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + Math.PI / 3);
                    colorRed = (int) (cR + (int) cG) / 2;
                    colorGreen = (int) (cR + (int) cG) / 2;
                    colorBlue = (int) (cR + (int) cG) / 2;

                    colorRed = (int)colorRed + 2 * (red - 127);

                    //colorGreen = colorGreen + green;
                    colorGreen = (int)colorGreen + 2 * (green - 127);

                    //colorBlue = colorBlue + blue;
                    colorBlue = (int)colorBlue + 2 * (blue - 127);

                }

                //if (modes == 4) {
                //    xvalue1 = xmouse / xscreen;
                //    yvalue1 = ymouse / yscreen;
                //    cR = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1))));
                //    cG = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1 + 2 * Math.PI / 3))));
                //    cB = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1 + 4 * Math.PI / 3))));
                //    cR = cR * 2;
                //    cG = cG * 2;
                //    cB = cB * 2;
                //    if (cR < 0) cR = -cR;
                //    if (cG < 0) cG = -cG;
                //    if (cB < 0) cB = -cB;
                //    if (cR > 255) cR = 255;
                //    if (cG > 255) cG = 255;
                //    if (cB > 255) cB = 255;
                //    colorRed = (int) cR;
                //    colorGreen = (int) cG;
                //    colorBlue = (int) cB;
                //}
                //
                //if (time == 5) {
                //    xvalue1 = xmouse / xscreen;
                //    yvalue1 = ymouse / yscreen;
                //    cR = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1))));
                //    cG = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1 + 2 * Math.PI / 3))));
                //    cB = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1 + 4 * Math.PI / 3))));
                //    if (cR < 0) cR = -cR;
                //    if (cG < 0) cG = -cG;
                //    if (cB < 0) cB = -cB;
                //    if (cR > 255) cR = 255;
                //    if (cG > 255) cG = 255;
                //    if (cB > 255) cB = 255;
                //    colorRed = (int) cR;
                //    colorGreen = (int) cG;
                //    colorBlue = (int) cB;
                //}
                if (colorRed > 255)
                    colorRed = 255;
                if (colorGreen > 255)
                    colorGreen= 255;
                if (colorBlue > 255)
                    colorBlue = 255;

                if (colorRed < 0)
                    colorRed = 0;
                if (colorGreen < 0)
                    colorGreen = 0;
                if (colorBlue < 0)
                    colorBlue = 0;
                if (modes == 1 || modes == 2|| modes == 3 || modes == 4 || modes == 5) {
                    r1 = colorRed - 255;
                    g1 = colorGreen - 255;
                    b1 = colorBlue - 255;
                    text.setTextColor(Color.rgb(r1, b1, g1));
                    text.setText("Red:" + colorRed + "Green:" + colorGreen + "Blue:" + colorBlue + "Mode:" + modes + "Steps:" + time);
                    layout.setBackgroundColor(Color.argb(255, colorRed, colorGreen, colorBlue));
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        sbGreen.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                green = i;

                if(modes == 0) {
                    layout.setBackgroundColor(Color.argb(255, red, green, blue));
                    text.setText("Red:" + red + "Green:" + green + "Blue:" + blue + "Mode:" + modes + "Steps:" + time);
                }
                if (modes == 1) {
                    colorRed = time + 1;
                    colorGreen = colorRed + 85;
                    colorBlue = colorRed + 170;

                    if (colorRed > 255) colorRed = 0;
                    if (colorGreen > 255) colorGreen = colorGreen - 255;
                    if (colorBlue > 255) colorBlue = colorBlue - 255;

                    colorRed = (int)colorRed + 2 * (red - 127);

                    colorGreen = (int)colorGreen + 2 * (green - 127);

                    colorBlue = (int)colorBlue + 2 * (blue - 127);
                }

                if (modes == 2) {
                    cR = 255 / 2 + 255 / 2 * Math.sin(0.025 * time);
                    cG = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + 2 * Math.PI / 3);
                    cB = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + 4 * Math.PI / 3);
                    colorRed = (int) cR;
                    colorGreen = (int) cG;
                    colorBlue = (int) cB;


                    colorRed = (int)colorRed + 2 * (red - 127);

                    colorGreen = (int)colorGreen + 2 * (green - 127);

                    colorBlue = (int)colorBlue + 2 * (blue - 127);

                }

                if (modes == 3) {
                    time = time + 1;
                    if (time > 255) time = 0;
                    cR = 255 / 2 + 255 / 2 * Math.sin(0.025 * time);
                    cG = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + Math.PI / 3);
                    colorRed = (int) (cR + (int) cG) / 2;
                    colorGreen = (int) (cR + (int) cG) / 2;
                    colorBlue = (int) (cR + (int) cG) / 2;

                    colorRed = (int)colorRed + 2 * (red - 127);

                    //colorGreen = colorGreen + green;
                    colorGreen = (int)colorGreen + 2 * (green - 127);

                    //colorBlue = colorBlue + blue;
                    colorBlue = (int)colorBlue + 2 * (blue - 127);

                }

                //if (modes == 4) {
                //    xvalue1 = xmouse / xscreen;
                //    yvalue1 = ymouse / yscreen;
                //    cR = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1))));
                //    cG = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1 + 2 * Math.PI / 3))));
                //    cB = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1 + 4 * Math.PI / 3))));
                //    cR = cR * 2;
                //    cG = cG * 2;
                //    cB = cB * 2;
                //    if (cR < 0) cR = -cR;
                //    if (cG < 0) cG = -cG;
                //    if (cB < 0) cB = -cB;
                //    if (cR > 255) cR = 255;
                //    if (cG > 255) cG = 255;
                //    if (cB > 255) cB = 255;
                //    colorRed = (int) cR;
                //    colorGreen = (int) cG;
                //    colorBlue = (int) cB;
                //}
                //
                //if (time == 5) {
                //    xvalue1 = xmouse / xscreen;
                //    yvalue1 = ymouse / yscreen;
                //    cR = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1))));
                //    cG = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1 + 2 * Math.PI / 3))));
                //    cB = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1 + 4 * Math.PI / 3))));
                //    if (cR < 0) cR = -cR;
                //    if (cG < 0) cG = -cG;
                //    if (cB < 0) cB = -cB;
                //    if (cR > 255) cR = 255;
                //    if (cG > 255) cG = 255;
                //    if (cB > 255) cB = 255;
                //    colorRed = (int) cR;
                //    colorGreen = (int) cG;
                //    colorBlue = (int) cB;
                //}
                if (colorRed > 255)
                    colorRed = 255;
                if (colorGreen > 255)
                    colorGreen= 255;
                if (colorBlue > 255)
                    colorBlue = 255;

                if (colorRed < 0)
                    colorRed = 0;
                if (colorGreen < 0)
                    colorGreen = 0;
                if (colorBlue < 0)
                    colorBlue = 0;
                if (modes == 1 || modes == 2|| modes == 3 || modes == 4 || modes == 5) {
                    text.setText("Red:" + colorRed + "Green:" + colorGreen + "Blue:" + colorBlue + "Mode:" + modes + "Steps:" + time);
                    r1 = colorRed - 255;
                    g1 = colorGreen - 255;
                    b1 = colorBlue - 255;
                    text.setTextColor(Color.rgb(r1, b1, g1));
                    layout.setBackgroundColor(Color.argb(255, colorRed, colorGreen, colorBlue));
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        sbBlue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                blue = i;
                if(modes == 0) {
                    layout.setBackgroundColor(Color.argb(255, red, green, blue));
                    text.setText("Red:" + red + "Green:" + green + "Blue:" + blue + "Mode:" + modes + "Steps:" + time);
                }
                if (modes == 1) {
                    colorRed = time + 1;
                    colorGreen = colorRed + 85;
                    colorBlue = colorRed + 170;

                    if (colorRed > 255) colorRed = 0;
                    if (colorGreen > 255) colorGreen = colorGreen - 255;
                    if (colorBlue > 255) colorBlue = colorBlue - 255;

                    colorRed = (int)colorRed + 2 * (red - 127);

                    colorGreen = (int)colorGreen + 2 * (green - 127);

                    colorBlue = (int)colorBlue + 2 * (blue - 127);
                }

                if (modes == 2) {
                    cR = 255 / 2 + 255 / 2 * Math.sin(0.025 * time);
                    cG = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + 2 * Math.PI / 3);
                    cB = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + 4 * Math.PI / 3);
                    colorRed = (int) cR;
                    colorGreen = (int) cG;
                    colorBlue = (int) cB;


                    colorRed = (int)colorRed + 2 * (red - 127);

                    colorGreen = (int)colorGreen + 2 * (green - 127);

                    colorBlue = (int)colorBlue + 2 * (blue - 127);

                }

                if (modes == 3) {
                    time = time + 1;
                    if (time > 255) time = 0;
                    cR = 255 / 2 + 255 / 2 * Math.sin(0.025 * time);
                    cG = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + Math.PI / 3);
                    colorRed = (int) (cR + (int) cG) / 2;
                    colorGreen = (int) (cR + (int) cG) / 2;
                    colorBlue = (int) (cR + (int) cG) / 2;

                    colorRed = (int)colorRed + 2 * (red - 127);

                    //colorGreen = colorGreen + green;
                    colorGreen = (int)colorGreen + 2 * (green - 127);

                    //colorBlue = colorBlue + blue;
                    colorBlue = (int)colorBlue + 2 * (blue - 127);

                }

                //if (modes == 4) {
                //    xvalue1 = xmouse / xscreen;
                //    yvalue1 = ymouse / yscreen;
                //    cR = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1))));
                //    cG = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1 + 2 * Math.PI / 3))));
                //    cB = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1 + 4 * Math.PI / 3))));
                //    cR = cR * 2;
                //    cG = cG * 2;
                //    cB = cB * 2;
                //    if (cR < 0) cR = -cR;
                //    if (cG < 0) cG = -cG;
                //    if (cB < 0) cB = -cB;
                //    if (cR > 255) cR = 255;
                //    if (cG > 255) cG = 255;
                //    if (cB > 255) cB = 255;
                //    colorRed = (int) cR;
                //    colorGreen = (int) cG;
                //    colorBlue = (int) cB;
                //}
                //
                //if (time == 5) {
                //    xvalue1 = xmouse / xscreen;
                //    yvalue1 = ymouse / yscreen;
                //    cR = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1))));
                //    cG = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1 + 2 * Math.PI / 3))));
                //    cB = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1 + 4 * Math.PI / 3))));
                //    if (cR < 0) cR = -cR;
                //    if (cG < 0) cG = -cG;
                //    if (cB < 0) cB = -cB;
                //    if (cR > 255) cR = 255;
                //    if (cG > 255) cG = 255;
                //    if (cB > 255) cB = 255;
                //    colorRed = (int) cR;
                //    colorGreen = (int) cG;
                //    colorBlue = (int) cB;
                //}
                if (colorRed > 255)
                    colorRed = 255;
                if (colorGreen > 255)
                    colorGreen= 255;
                if (colorBlue > 255)
                    colorBlue = 255;

                if (colorRed < 0)
                    colorRed = 0;
                if (colorGreen < 0)
                    colorGreen = 0;
                if (colorBlue < 0)
                    colorBlue = 0;
                if (modes == 1 || modes == 2|| modes == 3 || modes == 4 || modes == 5) {
                    text.setText("Red:" + colorRed + "Green:" + colorGreen + "Blue:" + colorBlue + "Mode:" + modes + "Steps:" + time);
                    r1 = colorRed - 255;
                    g1 = colorGreen - 255;
                    b1 = colorBlue - 255;
                    text.setTextColor(Color.rgb(r1, b1, g1));
                    layout.setBackgroundColor(Color.argb(255, colorRed, colorGreen, colorBlue));
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        //Modes
        modes1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                modes = i;

                if(modes == 0) {
                    layout.setBackgroundColor(Color.argb(255, red, green, blue));
                    text.setText("Red:" + red + "Green:" + green + "Blue:" + blue + "Mode:" + modes + "Steps:" + time);
                }
                if (modes == 1) {
                    colorRed = time + 1;
                    colorGreen = colorRed + 85;
                    colorBlue = colorRed + 170;

                    if (colorRed > 255) colorRed = 0;
                    if (colorGreen > 255) colorGreen = colorGreen - 255;
                    if (colorBlue > 255) colorBlue = colorBlue - 255;

                    colorRed = (int)colorRed + 2 * (red - 127);

                    colorGreen = (int)colorGreen + 2 * (green - 127);

                    colorBlue = (int)colorBlue + 2 * (blue - 127);
                }

                if (modes == 2) {
                    cR = 255 / 2 + 255 / 2 * Math.sin(0.025 * time);
                    cG = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + 2 * Math.PI / 3);
                    cB = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + 4 * Math.PI / 3);
                    colorRed = (int) cR;
                    colorGreen = (int) cG;
                    colorBlue = (int) cB;


                    colorRed = (int)colorRed + 2 * (red - 127);

                    colorGreen = (int)colorGreen + 2 * (green - 127);

                    colorBlue = (int)colorBlue + 2 * (blue - 127);

                }

                if (modes == 3) {
                    time = time + 1;
                    if (time > 255) time = 0;
                    cR = 255 / 2 + 255 / 2 * Math.sin(0.025 * time);
                    cG = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + Math.PI / 3);
                    colorRed = (int) (cR + (int) cG) / 2;
                    colorGreen = (int) (cR + (int) cG) / 2;
                    colorBlue = (int) (cR + (int) cG) / 2;

                    colorRed = (int)colorRed + 2 * (red - 127);

                    //colorGreen = colorGreen + green;
                    colorGreen = (int)colorGreen + 2 * (green - 127);

                    //colorBlue = colorBlue + blue;
                    colorBlue = (int)colorBlue + 2 * (blue - 127);

                }

                //if (modes == 4) {
                //    xvalue1 = xmouse / xscreen;
                //    yvalue1 = ymouse / yscreen;
                //    cR = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1))));
                //    cG = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1 + 2 * Math.PI / 3))));
                //    cB = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1 + 4 * Math.PI / 3))));
                //    cR = cR * 2;
                //    cG = cG * 2;
                //    cB = cB * 2;
                //    if (cR < 0) cR = -cR;
                //    if (cG < 0) cG = -cG;
                //    if (cB < 0) cB = -cB;
                //    if (cR > 255) cR = 255;
                //    if (cG > 255) cG = 255;
                //    if (cB > 255) cB = 255;
                //    colorRed = (int) cR;
                //    colorGreen = (int) cG;
                //    colorBlue = (int) cB;
                //}
                //
                //if (time == 5) {
                //    xvalue1 = xmouse / xscreen;
                //    yvalue1 = ymouse / yscreen;
                //    cR = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1))));
                //    cG = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1 + 2 * Math.PI / 3))));
                //    cB = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1 + 4 * Math.PI / 3))));
                //    if (cR < 0) cR = -cR;
                //    if (cG < 0) cG = -cG;
                //    if (cB < 0) cB = -cB;
                //    if (cR > 255) cR = 255;
                //    if (cG > 255) cG = 255;
                //    if (cB > 255) cB = 255;
                //    colorRed = (int) cR;
                //    colorGreen = (int) cG;
                //    colorBlue = (int) cB;
                //}
                if (colorRed > 255)
                    colorRed = 255;
                if (colorGreen > 255)
                    colorGreen= 255;
                if (colorBlue > 255)
                    colorBlue = 255;

                if (colorRed < 0)
                    colorRed = 0;
                if (colorGreen < 0)
                    colorGreen = 0;
                if (colorBlue < 0)
                    colorBlue = 0;
                if (modes == 1 || modes == 2|| modes == 3 || modes == 4 || modes == 5) {
                    text.setText("Red:" + colorRed + "Green:" + colorGreen + "Blue:" + colorBlue + "Mode:" + modes + "Steps:" + time);
                    r1 = colorRed - 255;
                    g1 = colorGreen - 255;
                    b1 = colorBlue - 255;
                    text.setTextColor(Color.rgb(r1, b1, g1));
                    layout.setBackgroundColor(Color.argb(255, colorRed, colorGreen, colorBlue));
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        Time.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                time = i;

                if (modes == 1) {
                    colorRed = time + 1;
                    colorGreen = colorRed + 85;
                    colorBlue = colorRed + 170;

                    if (colorRed > 255) colorRed = 0;
                    if (colorGreen > 255) colorGreen = colorGreen - 255;
                    if (colorBlue > 255) colorBlue = colorBlue - 255;

                    colorRed = (int)colorRed + 2 * (red - 127);

                    colorGreen = (int)colorGreen + 2 * (green - 127);

                    colorBlue = (int)colorBlue + 2 * (blue - 127);
                }

                if (modes == 2) {
                    cR = 255 / 2 + 255 / 2 * Math.sin(0.025 * time);
                    cG = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + 2 * Math.PI / 3);
                    cB = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + 4 * Math.PI / 3);
                    colorRed = (int) cR;
                    colorGreen = (int) cG;
                    colorBlue = (int) cB;


                    colorRed = (int)colorRed + 2 * (red - 127);

                    colorGreen = (int)colorGreen + 2 * (green - 127);

                    colorBlue = (int)colorBlue + 2 * (blue - 127);

                }

                if (modes == 3) {
                    time = time + 1;
                    if (time > 255) time = 0;
                    cR = 255 / 2 + 255 / 2 * Math.sin(0.025 * time);
                    cG = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + Math.PI / 3);
                    colorRed = (int) (cR + (int) cG) / 2;
                    colorGreen = (int) (cR + (int) cG) / 2;
                    colorBlue = (int) (cR + (int) cG) / 2;

                    colorRed = (int)colorRed + 2 * (red - 127);

                    //colorGreen = colorGreen + green;
                    colorGreen = (int)colorGreen + 2 * (green - 127);

                    //colorBlue = colorBlue + blue;
                    colorBlue = (int)colorBlue + 2 * (blue - 127);

                }

                //if (modes == 4) {
                //    xvalue1 = xmouse / xscreen;
                //    yvalue1 = ymouse / yscreen;
                //    cR = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1))));
                //    cG = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1 + 2 * Math.PI / 3))));
                //    cB = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1 + 4 * Math.PI / 3))));
                //    cR = cR * 2;
                //    cG = cG * 2;
                //    cB = cB * 2;
                //    if (cR < 0) cR = -cR;
                //    if (cG < 0) cG = -cG;
                //    if (cB < 0) cB = -cB;
                //    if (cR > 255) cR = 255;
                //    if (cG > 255) cG = 255;
                //    if (cB > 255) cB = 255;
                //    colorRed = (int) cR;
                //    colorGreen = (int) cG;
                //    colorBlue = (int) cB;
                //}
                //
                //if (time == 5) {
                //    xvalue1 = xmouse / xscreen;
                //    yvalue1 = ymouse / yscreen;
                //    cR = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1))));
                //    cG = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1 + 2 * Math.PI / 3))));
                //    cB = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1 + 4 * Math.PI / 3))));
                //    if (cR < 0) cR = -cR;
                //    if (cG < 0) cG = -cG;
                //    if (cB < 0) cB = -cB;
                //    if (cR > 255) cR = 255;
                //    if (cG > 255) cG = 255;
                //    if (cB > 255) cB = 255;
                //    colorRed = (int) cR;
                //    colorGreen = (int) cG;
                //    colorBlue = (int) cB;
                //}
                if (colorRed > 255)
                    colorRed = 255;
                if (colorGreen > 255)
                    colorGreen= 255;
                if (colorBlue > 255)
                    colorBlue = 255;

                if (colorRed < 0)
                    colorRed = 0;
                if (colorGreen < 0)
                    colorGreen = 0;
                if (colorBlue < 0)
                    colorBlue = 0;

                layout.setBackgroundColor(Color.argb(255, colorRed, colorGreen, colorBlue));
                if (modes == 1 || modes == 2|| modes == 3 || modes == 4 || modes == 5) {
                    text.setText("Red:" + colorRed + "Green:" + colorGreen + "Blue:" + colorBlue + "Mode:" + modes + "Steps:" + time);
                }
                if(modes == 0) {
                    text.setText("Red:" + red + "Green:" + green + "Blue:" + blue + "Mode:" + modes + "Steps:" + time);
                    layout.setBackgroundColor(Color.argb(255, red, green, blue));
                    r1 =colorRed - 255;
                    g1 = colorGreen - 255;
                    b1 = colorBlue - 255;
                    text.setTextColor(Color.rgb(r1,b1,g1));
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });



    }

    //public method;{
    //    if (modes == 1) {
    //        colorRed = time + 1;
    //        colorGreen = colorRed + 85;
    //        colorBlue = colorRed + 170;
//
    //        if (colorRed > 255) colorRed = 0;
    //        if (colorGreen > 255) colorGreen = colorGreen - 255;
    //        if (colorBlue > 255) colorBlue = colorBlue - 255;
//
    //        colorRed = (int)colorRed + 2 * (red - 127);
//
    //        colorGreen = (int)colorGreen + 2 * (green - 127);
//
    //        colorBlue = (int)colorBlue + 2 * (blue - 127);
    //    }
//
    //    if (modes == 2) {
    //        cR = 255 / 2 + 255 / 2 * Math.sin(0.025 * time);
    //        cG = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + 2 * Math.PI / 3);
    //        cB = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + 4 * Math.PI / 3);
    //        colorRed = (int) cR;
    //        colorGreen = (int) cG;
    //        colorBlue = (int) cB;
//
//
    //        colorRed = (int)colorRed + 2 * (red - 127);
//
    //        colorGreen = (int)colorGreen + 2 * (green - 127);
//
    //        colorBlue = (int)colorBlue + 2 * (blue - 127);
//
    //    }
//
    //    if (modes == 3) {
    //        time = time + 1;
    //        if (time > 255) time = 0;
    //        cR = 255 / 2 + 255 / 2 * Math.sin(0.025 * time);
    //        cG = 255 / 2 + 255 / 2 * Math.sin(0.025 * time + Math.PI / 3);
    //        colorRed = (int) (cR + (int) cG) / 2;
    //        colorGreen = (int) (cR + (int) cG) / 2;
    //        colorBlue = (int) (cR + (int) cG) / 2;
//
    //        colorRed = (int)colorRed + 2 * (red - 127);
//
    //        //colorGreen = colorGreen + green;
    //        colorGreen = (int)colorGreen + 2 * (green - 127);
//
    //        //colorBlue = colorBlue + blue;
    //        colorBlue = (int)colorBlue + 2 * (blue - 127);
//
    //    }
//
    //    //if (modes == 4) {
    //    //    xvalue1 = xmouse / xscreen;
    //    //    yvalue1 = ymouse / yscreen;
    //    //    cR = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1))));
    //    //    cG = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1 + 2 * Math.PI / 3))));
    //    //    cB = (yvalue1 * 255 * ((Math.sin(1 * Math.PI * xvalue1 + 4 * Math.PI / 3))));
    //    //    cR = cR * 2;
    //    //    cG = cG * 2;
    //    //    cB = cB * 2;
    //    //    if (cR < 0) cR = -cR;
    //    //    if (cG < 0) cG = -cG;
    //    //    if (cB < 0) cB = -cB;
    //    //    if (cR > 255) cR = 255;
    //    //    if (cG > 255) cG = 255;
    //    //    if (cB > 255) cB = 255;
    //    //    colorRed = (int) cR;
    //    //    colorGreen = (int) cG;
    //    //    colorBlue = (int) cB;
    //    //}
    //    //
    //    //if (time == 5) {
    //    //    xvalue1 = xmouse / xscreen;
    //    //    yvalue1 = ymouse / yscreen;
    //    //    cR = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1))));
    //    //    cG = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1 + 2 * Math.PI / 3))));
    //    //    cB = (xvalue1 * 255 * ((Math.sin(1 * Math.PI * yvalue1 + 4 * Math.PI / 3))));
    //    //    if (cR < 0) cR = -cR;
    //    //    if (cG < 0) cG = -cG;
    //    //    if (cB < 0) cB = -cB;
    //    //    if (cR > 255) cR = 255;
    //    //    if (cG > 255) cG = 255;
    //    //    if (cB > 255) cB = 255;
    //    //    colorRed = (int) cR;
    //    //    colorGreen = (int) cG;
    //    //    colorBlue = (int) cB;
    //    //}
    //    if (colorRed > 255)
    //        colorRed = 255;
    //    if (colorGreen > 255)
    //        colorGreen= 255;
    //    if (colorBlue > 255)
    //        colorBlue = 255;
//
    //    if (colorRed < 0)
    //        colorRed = 0;
    //    if (colorGreen < 0)
    //        colorGreen = 0;
    //    if (colorBlue < 0)
    //        colorBlue = 0;
//
    //    layout.setBackgroundColor(Color.argb(255, colorRed, colorGreen, colorBlue));
    //    if (modes == 1 || modes == 2|| modes == 3 || modes == 4 || modes == 5) {
    //        text.setText("Red:" + colorRed + "Green:" + colorGreen + "Blue:" + colorBlue + "Mode:" + modes + "Steps:" + time);
    //    }
    //    if(modes == 0) {
    //        text.setText("Red:" + red + "Green:" + green + "Blue:" + blue + "Mode:" + modes + "Steps:" + time);
    //        layout.setBackgroundColor(Color.argb(255, red, green, blue));
    //        r1 =colorRed - 255;
    //        g1 = colorGreen - 255;
    //        b1 = colorBlue - 255;
    //        text.setTextColor(Color.rgb(r1,b1,g1));
    //    }
    //}
}//
